let main = document.querySelector(".main"),
    signUpLink = document.querySelector(".link .signup-link"),
    loginLink = document.querySelector(".link .login-link");

signUpLink.addEventListener("click", () => {
    main.classList.add("animated-login");
    main.classList.remove("animated-signup");
});

loginLink.addEventListener("click", () => {
    main.classList.add("animated-signup");
    main.classList.remove("animated-login");
});