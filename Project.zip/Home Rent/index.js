// Side Contents
var list = `<ul>`;
for(let i=1; i<=24; i++){
    const lists = ["About You", "You", "Wallet", "Rent", "Tour", "Games", "Calender", "About", "Properties", "Services", "Settings", "Log Out"]
    list += `<li id="trgt">${lists[i%12]}</li>`;
}
list += `</ul>`;
document.querySelector("#side-content").innerHTML = list;


//Sliding Contents
var pic = "", slide = "";
for(let i=1; i<=5; i++) pic += `<img src="Houses/home-${i}.jpg" alt="Home-${i}">`;
for(let j=1; j<=2; j++) slide += `<div class="images">${pic}</div>`;
document.querySelector(".latest").innerHTML = slide;


//Properties
var info = "";
for(let i=1; i<=24; i++){
    const rent = ["5,500", "9,500", "7,000", "3,500", "8,000", "4,000", "6,000", "5,000", "10,000", "4,500"];
    const location = ["Savar","Ashulia","Dattapara","Khagan","Charabag","Uttara","Mirpur","Akrain","Changao","Nabinagar"];
    info += `<div class="box house-info">
                <a href="details.html"><img src="Houses/home-${i}.jpg" alt="home-${i} id="Img"></a>
                <h3>Location : ${location[i%10]}</h3>
                <h5>Rent : ${rent[i%10]}&#2547;</h5>
                <a href="details.html"><button id="btn" onclick="info()">View Details</button></a>
                <a href="rent.html"><button id="btn">Rent</button></a>
            </div>`;
    
}
document.querySelector(".content").innerHTML = info;